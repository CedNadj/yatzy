import 'package:encrypted_shared_preferences/encrypted_shared_preferences.dart';

class DataRepository {
  static var loginName = "";
  static var firstName = "";
  static var lastName = "";
  static var phoneNumber = "";
  static var emailAddress = "";

  static final EncryptedSharedPreferences prefs = EncryptedSharedPreferences();

  /// Loads saved data from encrypted shared preferences
  static Future<void> loadData() async {
    loginName = await prefs.getString('loginName');
    firstName = await prefs.getString('firstName');
    lastName = await prefs.getString('lastName');
    phoneNumber = await prefs.getString('phoneNumber');
    emailAddress = await prefs.getString('emailAddress');
  }

  /// Saves data securely
  static Future<void> saveData() async {
    await prefs.setString('loginName', loginName);
    await prefs.setString('firstName', firstName);
    await prefs.setString('lastName', lastName);
    await prefs.setString('phoneNumber', phoneNumber);
    await prefs.setString('emailAddress', emailAddress);
  }

  /// Clears everything
  static Future<void> clearData() async {
    await prefs.clear();
  }
}