import 'package:flutter/material.dart';
import 'package:encrypted_shared_preferences/encrypted_shared_preferences.dart';
import 'ProfilePage.dart';
import 'DataRepository.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await DataRepository.loadData(); // load saved data before app starts
  runApp(const MyApp());
}
//Root widget of the application
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Lab 5 App',
      initialRoute: '/',
      routes: {
        '/': (context) => const MyLoginPage(title: 'Lab5'),
        '/profile': (context) => ProfilePage(),
      },
      //Sets the primary color scheme for the app
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
      ),
    );
  }
}
//Stateful widget to manage dynamic UI changes
class MyLoginPage extends StatefulWidget {
  const MyLoginPage({super.key, required this.title});
  final String title;

  @override
  State<MyLoginPage> createState() => MyLoginPageState();
}
class MyLoginPageState extends State<MyLoginPage> {
  //Controllers to retrieve text from the input fields
  late TextEditingController loginController;
  late TextEditingController passwordController;
  final EncryptedSharedPreferences prefs = EncryptedSharedPreferences();

  var imageSource = 'images/sleep.png';
  var loadedFromPrefs = false;

  @override
  void initState(){
    super.initState();
    //Initialize text controllers when the widget is created
    loginController = TextEditingController();
    passwordController = TextEditingController();
    loadSavedCredentials();
  }

  //Load encrypted credentials when the app starts
  void loadSavedCredentials() async {
    String? savedUser = await prefs.getString('username');
    String? savedPass = await prefs.getString('password');

    // Safely check if both are not null AND not empty
    if (savedUser.isNotEmpty == true && savedPass.isNotEmpty == true) {
      setState(() {
        loginController.text = savedUser;
        passwordController.text = savedPass;
        loadedFromPrefs = true;
      });

      _showSnackBar();
    }
  }

  //SnackBar appears if credentials were loaded successfully
  void _showSnackBar() {
    final snackBar = SnackBar(
      content: const Text('Previous login credentials loaded.'),
      action: SnackBarAction(
        label: 'Undo',
        onPressed: (){
          //Undo clears the text fields but does not delete from storage
          setState((){
            loginController.clear();
            passwordController.clear();
          });
        },
      ),
      duration: const Duration(seconds: 4),
    );

    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  //Called when login button is pressed
  void loginPressed(){
    final password = passwordController.text.trim();

    //Update image based on password value
    setState((){
      if (password.isEmpty){
        imageSource = 'images/question-mark.png';
      } else if (password == 'QWERTY123') {
        imageSource = 'images/idea.png';

        // Save the login name in the repository
        DataRepository.loginName

        // Navigate to Profile Page
        Navigator.pushNamed(context, '/profile');

        // Show "Welcome Back" SnackBar
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Welcome Back, ${loginController.text}')),
        );
      } else {
        imageSource = 'images/stop.png';
      }
    });

    //After showing the image, show dialog asking whether to save login
    showSaveDialog();
  }

  //AlertDialog asking if the user wants to save credentials
  void showSaveDialog(){
    showDialog<String>(
      context: context,
      builder: (BuildContext context){
        return AlertDialog(
          title: const Text('Save Login Info?'),
          content: const Text('Would you like to save your username and password for the next time?'),
          actions: <Widget>[
            TextButton(
              onPressed: (){
                //User clicked NO -> clear stored credentials
                prefs.remove('username');
                prefs.remove('password');
                Navigator.pop(context);
              },
              child: const Text('No'),
            ),
            TextButton(
              onPressed: () {
                //User clicked YES -> save credentials securely
                prefs.setString('username', loginController.text);
                prefs.setString('password', passwordController.text);
                Navigator.pop(context);
              },
              child: const Text('Yes'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          //Uses theme color for the app bar
          backgroundColor: Theme.of(context).colorScheme.inversePrimary,
          title: Text(widget.title),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                const SizedBox(height: 12),

                //TextField for login name input
                TextField(
                  controller: loginController,
                  decoration: const InputDecoration(
                    labelText: 'Login name',
                    border: OutlineInputBorder(),
                  ),
                ),

                //For the password setup
                const SizedBox(height: 12),

                //TextField for password input with obscured text
                TextField(
                  controller: passwordController,
                  obscureText: true, //Hides the password characters
                  decoration: const InputDecoration(
                    labelText: 'Password',
                    border: OutlineInputBorder(),
                  ),
                ),

                //The button once the user added his/her information
                const SizedBox(height: 16),
                //Elevated button to trigger login logic
                ElevatedButton(
                  onPressed: loginPressed,
                  child: const Text('Login'),
                ),

                //Image widget that updates based on login result
                const SizedBox(height: 18),
                SizedBox(
                    width: 300,
                    height: 300,
                    child: Image.asset(imageSource,
                      fit: BoxFit.contain,)
                )
              ],
            ),
          ),
        )
    );
  }
}