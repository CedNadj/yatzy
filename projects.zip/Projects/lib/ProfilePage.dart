
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'DataRepository.dart';

class ProfilePage extends StatefulWidget{
  @override
  State<ProfilePage> createState() => ProfilePageState();
}

class ProfilePageState extends State<ProfilePage>{
  final firstName = TextEditingController();
  final lastName = TextEditingController();
  final phone = TextEditingController();
  final email = TextEditingController();

  @override
  void initState(){
    super.initState();
    loadFields();
  }

  void loadFields(){
    firstName.text = DataRepository.firstName;
    lastName.text = DataRepository.lastName;
    phone.text = DataRepository.phoneNumber;
    email.text = DataRepository.emailAddress;
  }

  @override
  void dispose(){
    DataRepository.firstName = firstName.text;
    DataRepository.lastName = lastName.text;
    DataRepository.phoneNumber = phone.text;
    DataRepository.emailAddress = email.text;
    DataRepository.saveData();
    super.dispose();
  }

  Future<void> launchURL(String urlScheme) async{
    final Uri url = Uri.parse(urlScheme);
    if (!await launchUrl(url)){
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text("Unsupported"),
          content: Text("This device cannot launch:\n$urlScheme"),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("OK"),
            )
          ],
        ),
      );
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Profile Page")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Welcome Back ${DataRepository.loginName}",
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),

            TextField(
              controller: firstName,
              decoration: const InputDecoration(labelText: "First Name"),
            ),
            TextField(
              controller: lastName,
              decoration: const InputDecoration(labelText: "Last Name"),
            ),
            const SizedBox(height: 10),

            Row(
              children: [
                Flexible(
                  child: TextField(
                    controller: phone,
                    keyboardType: TextInputType.phone,
                    decoration: const InputDecoration(labelText: "Phone Number"),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: () => launchURL("tel:${phone.text}"),
                  child: const Icon(Icons.phone),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: () => launchURL("sms:${phone.text}"),
                  child: const Icon(Icons.message),
                ),
              ],
            ),

            const SizedBox(height: 10),

            Row(
              children: [
                Flexible(
                  child: TextField(
                    controller: email,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(labelText: "Email Address"),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: () => launchURL("mailto:${email.text}"),
                  child: const Icon(Icons.mail),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
